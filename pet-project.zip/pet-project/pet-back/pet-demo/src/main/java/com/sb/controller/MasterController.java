package com.sb.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sb.service.MasterService;
import com.sb.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("master")
@CrossOrigin
public class MasterController {
    @Autowired
    private MasterService masterService;

    @GetMapping("getAllMaster")
    public Result getAllMaster(){
        return masterService.getAllMaster();
    }

    @PostMapping("addMaster")
    public Result addMaster(@RequestBody JSONObject params){
        JSONArray controllerParams = new JSONArray();
        controllerParams.add(params.get("masterAddress"));
        controllerParams.add(params.get("masterName"));
        controllerParams.add(params.get("masterAge"));
        return masterService.addMaster(controllerParams);
    }

    @GetMapping("removeMaster")
    public Result removeMaster(String masterAddress){
        JSONArray controllerParams = new JSONArray();
        controllerParams.add(masterAddress);
        return masterService.removeMaster(controllerParams);
    }

    @GetMapping("getMaster")
    public Result getMaster(String masterAddress){
        JSONArray controllerParams = new JSONArray();
        controllerParams.add(masterAddress);
        return masterService.getMaster(controllerParams);
    }

    @GetMapping("getMyPet")
    public Result getMyPet(String masterAddress){
        JSONArray controllerParams = new JSONArray();
        controllerParams.add(masterAddress);
        return masterService.getMyPet(controllerParams);
    }

    @GetMapping("getMyPetToList")
    public Result getMyPetToList(String masterAddress){
        JSONArray controllerParams = new JSONArray();
        controllerParams.add(masterAddress);
        return masterService.getMyPetToList(controllerParams);
    }

    @PostMapping("savePet")
    public Result savePet(@RequestBody JSONObject params){
        JSONArray controllerParam = new JSONArray();
        controllerParam.add(params.get("applicant"));
        controllerParam.add(params.get("petId"));
        return masterService.savePet(controllerParam);
    }

    @PostMapping("transferPet")
    public Result transferPet(@RequestBody JSONObject params){
        JSONArray controllerParam = new JSONArray();
        controllerParam.add(params.get("from"));
        controllerParam.add(params.get("to"));
        controllerParam.add(params.get("petId"));
        return masterService.transferPet(controllerParam);
    }

    @PostMapping("addMoney")
    public Result addMoney(@RequestBody JSONObject params){
        JSONArray controllerParam = new JSONArray();
        controllerParam.add(params.get("masterAddress"));
        controllerParam.add(params.get("amount"));
        return masterService.addMoney(controllerParam);
    }
}
