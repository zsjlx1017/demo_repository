package com.sb.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sb.service.PetService;
import com.sb.utils.Result;
import com.sb.utils.WeBASEUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("pet")
public class PetController {

    @Autowired
    PetService petService;

    @GetMapping("getAllPet")
    public Result getAllPet(){
        return petService.getAllPet();
    }
    @PostMapping("addPet")
    public Result addPet(@RequestBody JSONObject params){
        JSONArray controllerParam = new JSONArray();
        String petName = (String)params.get("petName");
        Integer petAge = Integer.parseInt(params.get("petAge").toString());
        controllerParam.add(petName);
        controllerParam.add(petAge);
        return petService.addpet(controllerParam);
    }
    @GetMapping("getPet")
    public Result getPet(Integer petId){
        Result allPet = getAllPet();
        Integer data = (Integer)allPet.getData();
        if(petId > data || petId == null){
            return Result.error("超出所有宠物范围");
        }
        JSONArray controllerParam = new JSONArray();
        controllerParam.add(petId);
        return petService.getPet(controllerParam);
    }
    @GetMapping("removePet")
    public Result removePet(Integer petId){
        JSONArray controllerParam = new JSONArray();
        controllerParam.add(petId);
        return petService.removePet(controllerParam);
    }

    @GetMapping("getAllPetToList")
    public Result getAllPetToList(){
        return petService.getAllPetToList();
    }





}
