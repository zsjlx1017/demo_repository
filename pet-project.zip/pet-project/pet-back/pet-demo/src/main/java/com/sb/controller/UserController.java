package com.sb.controller;

import com.alibaba.fastjson.JSONObject;
import com.sb.service.MasterService;
import com.sb.service.UserService;
import com.sb.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("user")
@CrossOrigin
public class UserController {

    @Autowired
    private UserService userService;


    @PostMapping("login")
    public Result login(@RequestBody JSONObject params){
        String masterAddress = (String)params.get("masterAddress");
        String masterPassword = (String)params.get("masterPassword");
        return userService.login(masterAddress, masterPassword);
    }

    @PostMapping("register")
    public Result register(@RequestBody JSONObject params){
        String masterAddress = (String)params.get("masterAddress");
        String masterName = (String)params.get("masterName");
        String masterPassword = (String)params.get("masterPassword");
        return userService.register(masterAddress, masterName, masterPassword);
    }

    @GetMapping("getUser")
    public Result getUser(String masterAddress){
        return userService.getUser(masterAddress);
    }

//    @PostMapping("register")
//    public Result register(@RequestBody JSONObject params){
//        String masterAddress = (String)params.get("masterAddress");
//        String masterPassword = (String)params.get("masterPassword");
//        return userService.register(masterAddress, masterPassword);
//    }

}
