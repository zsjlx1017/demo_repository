package com.sb.mapper;

import com.sb.pojo.User;

public interface UserMapper {
    User selectOneById(Integer id);
    User selectOneByAddress(String masterAddress);

    int insertOne(User user);

}
