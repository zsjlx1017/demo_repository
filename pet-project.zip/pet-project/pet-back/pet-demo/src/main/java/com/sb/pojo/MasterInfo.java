package com.sb.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.fisco.bcos.sdk.abi.datatypes.Int;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MasterInfo {
    private String masterAddress;
    private String masterName;
    private Integer masterAge;
    private Object masterPet;
    private Integer money;
    private Integer masterStatus;
}
