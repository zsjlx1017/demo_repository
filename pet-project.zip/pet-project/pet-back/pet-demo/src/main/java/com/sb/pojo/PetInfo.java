package com.sb.pojo;

import com.alibaba.fastjson.JSONArray;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PetInfo {
    private Integer petId;
    private String petName;
    private Integer petAge;
    private String petMaster;
    private Integer petStatus;
}
