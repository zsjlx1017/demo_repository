package com.sb.service;

import com.alibaba.fastjson.JSONArray;
import com.sb.utils.Result;

public interface MasterService {
    /**
     * 获取所有的主人地址
     * @return
     */
    Result getAllMaster();

    /**
     * 传入 主人地址 主人名称 主人年龄 添加主人信息
     * 注意顺序!!!与合约一致
     * @param controllerParams
     * @return
     */
    Result addMaster(JSONArray controllerParams);

    /**
     * 通过传入主人地址来移除某个主人
     * @param controllerParams
     * @return
     */
    Result removeMaster(JSONArray controllerParams);

    /**
     * 通过某个地址查询这个主人的具体信息
     * @param controllerParams
     * @return
     */
    Result getMaster(JSONArray controllerParams);

    /**
     * 通过地址找到这个人的所有宠物
     * @param controllerParams
     * @return
     */
    Result getMyPet(JSONArray controllerParams);

    /**
     * 给申请人领养指定的宠物
     * @param controllerParam
     * @return
     */
    Result savePet(JSONArray controllerParam);

    /**
     * 传入from 和 to 以及petid来进行宠物主人的转移
     * @param controllerParam
     * @return
     */
    Result transferPet(JSONArray controllerParam);

    /**
     * 传入masterAddress 和 amount 来给主人充钱
     * @param controllerParam
     * @return
     */
    Result addMoney(JSONArray controllerParam);

    /**
     * 通过地址来找到其下所有的宠物
     * @param controllerParams
     * @return
     */
    Result getMyPetToList(JSONArray controllerParams);
}
