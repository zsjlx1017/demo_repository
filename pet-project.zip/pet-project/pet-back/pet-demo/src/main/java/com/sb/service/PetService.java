package com.sb.service;

import com.alibaba.fastjson.JSONArray;
import com.sb.utils.Result;

public interface PetService {

    /**
     * 获取所有的宠物所在的数组
     * @return
     */
    Result getAllPet();

    /**
     * 根据id添加一个宠物
     * @param controllerParam
     * @return
     */
    Result addpet(JSONArray controllerParam);

    /**
     * 查询具体某个宠物的信息
     * @param petId
     * @return
     */
    Result getPet(JSONArray petId);

    /**
     * 根据id来删除某个宠物
     * @param controllerParam
     * @return
     */
    Result removePet(JSONArray controllerParam);

    /**
     * 获取到链上所有的pet并转成list集合返回给前端
     * @return
     */
    Result getAllPetToList();
}
