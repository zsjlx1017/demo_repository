package com.sb.service;

import com.sb.utils.Result;

public interface UserService {

    /**
     * 传入账号密码进行登录
     * @param masterAddress
     * @param masterPassword
     * @return
     */
    Result login(String masterAddress, String masterPassword);

    /**
     * 使用账号密码进行注册
     *
     * @param masterAddress
     * @param masterPassword
     * @return
     */
    Result register(String masterAddress, String masterName, String masterPassword);

    /**
     * 通过一个地址来查询该用户
     * @param masterAddress
     * @return
     */
    Result getUser(String masterAddress);
}
