package com.sb.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sb.pojo.MasterInfo;
import com.sb.service.MasterService;
import com.sb.service.PetService;
import com.sb.utils.Result;
import com.sb.utils.WeBASEUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;

@Service
public class MasterServiceImpl implements MasterService {

    @Autowired
    private WeBASEUtil weBASEUtil;

    @Value("${bcos.owner}")
    private String owner;

    @Autowired
    private PetService petService;

    @Override
    public Result getAllMaster() {
        JSONObject getAllMaster = weBASEUtil.getJsonParam("getAllMaster", new JSONArray(), owner);
        String resp = weBASEUtil.httpPost(getAllMaster.toString());
        JSONArray objects = JSONArray.parseArray(resp);
        return Result.ok(objects.get(0));
    }

    @Override
    public Result addMaster(JSONArray controllerParams) {
        JSONObject addMaster = weBASEUtil.getJsonParam("addMaster", controllerParams, owner);
        String resp = weBASEUtil.httpPost(addMaster.toString());
        JSONObject respObj = JSONObject.parseObject(resp);
        Result r = Result.ok(respObj.get("message"));
        if(!(Boolean)respObj.get("statusOK")){
            r = Result.error("message");
        }
        return r;
    }

    @Override
    public Result removeMaster(JSONArray controllerParams) {
        JSONObject removeMaster = weBASEUtil.getJsonParam("removeMaster", controllerParams, owner);
        String resp = weBASEUtil.httpPost(removeMaster.toString());
        JSONObject respObj = JSONObject.parseObject(resp);
        Result r = Result.ok(respObj.get("message"));
        if(!(Boolean)respObj.get("statusOK")){
            r = Result.error("message");
        }
        return r;
    }

    @Override
    public Result getMaster(JSONArray controllerParams) {
        JSONObject getMaster = weBASEUtil.getJsonParam("getMaster", controllerParams, owner);
        String resp = weBASEUtil.httpPost(getMaster.toString());
        JSONArray masterArr = JSONArray.parseArray(resp);
        String masterAddress = (String)masterArr.get(0);
        String masterrName = (String)masterArr.get(1);
        Integer masterAge = (Integer)masterArr.get(2);
        Object masterPet = masterArr.get(3);
        Integer money = (Integer)masterArr.get(4);
        Integer status = (Integer)masterArr.get(5);
        MasterInfo masterInfo = new MasterInfo(masterAddress,masterrName,masterAge,masterPet,money,status);
        return Result.ok(masterInfo);
    }

    @Override
    public Result getMyPet(JSONArray controllerParams) {
        JSONObject getMyPet = weBASEUtil.getJsonParam("getMyPet", controllerParams, owner);
        String resp = weBASEUtil.httpPost(getMyPet.toString());
        JSONArray respArr = JSONArray.parseArray(resp);
        return Result.ok(respArr.get(0));
    }

    @Override
    public Result getMyPetToList(JSONArray controllerParams) {
        Result myPet = getMyPet(controllerParams);
        JSONArray data = (JSONArray)myPet.getData();
        JSONArray pets = new JSONArray();
        Result r;
        if(data != null){
            for (int i = 1; i <= data.size(); i++) {
                if (Integer.parseInt(data.get(i-1).toString()) != 0) {
                    JSONArray controllerParam = new JSONArray();
                    controllerParam.add(i);
                    Result pet = petService.getPet(controllerParam);
                    Object onePetInfo = pet.getData();
                    pets.add(onePetInfo);
                }
            }
            r = Result.ok(pets);
        }else{
            r = Result.error(null);
        }

        return r;
    }


    @Override
    public Result savePet(JSONArray controllerParam) {
        JSONObject savePet = weBASEUtil.getJsonParam("savePet", controllerParam, owner);
        String resp = weBASEUtil.httpPost(savePet.toString());
        JSONObject respObj = JSONObject.parseObject(resp);
        Result r = Result.ok(respObj.get("message"));
        if(!(Boolean)respObj.get("statusOK")){
            r = Result.error(respObj.get("message"));
        }
        return r;
    }


    @Override
    public Result transferPet(JSONArray controllerParam) {
        JSONObject transferPet = weBASEUtil.getJsonParam("transferPet", controllerParam, owner);
        String resp = weBASEUtil.httpPost(transferPet.toString());
        JSONObject respObj = JSONObject.parseObject(resp);
        Result r = Result.ok(respObj.get("message"));
        if(!(Boolean)respObj.get("statusOK")){
            r = Result.error(respObj.get("message"));
        }
        return r;
    }

    @Override
    public Result addMoney(JSONArray controllerParam) {
        JSONObject addMoney = weBASEUtil.getJsonParam("addMoney", controllerParam, owner);
        String resp = weBASEUtil.httpPost(addMoney.toString());
        JSONObject respObj = JSONObject.parseObject(resp);
        Result r = Result.ok(respObj.get("message"));
        if(!(Boolean)respObj.get("statusOK")){
            r = Result.error("message");
        }
        return r;
    }




}
