package com.sb.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sb.pojo.PetInfo;
import com.sb.service.PetService;
import com.sb.utils.Result;
import com.sb.utils.WeBASEUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PetServiceImpl implements PetService {


    @Autowired
    WeBASEUtil weBASEUtil;

    @Value("${bcos.owner}")
    private String owner;

    public Result getAllPet(){
        JSONObject getAllPet = weBASEUtil.getJsonParam("getAllPet", new JSONArray(), "");
        String resp = weBASEUtil.httpPost(getAllPet.toString());
        JSONArray objects = JSONArray.parseArray(resp);
        return Result.ok(objects.get(0));
    }

    @Override
    public Result addpet(JSONArray controllerParam) {
        JSONObject addPet = weBASEUtil.getJsonParam("addPet", controllerParam, owner);
        String resp = weBASEUtil.httpPost(addPet.toString());
        JSONObject respObject = JSONObject.parseObject(resp);
        Result result = Result.ok("success");
        if(!(Boolean) respObject.get("statusOK")){
            result = Result.error(respObject.get("message"));
        }
        return result;
    }

    @Override
    public Result getPet(JSONArray controllerParam) {
        JSONObject getPet = weBASEUtil.getJsonParam("getPet", controllerParam, owner);
        String resp = weBASEUtil.httpPost(getPet.toString());
        JSONArray respArr = JSONArray.parseArray(resp);
        Integer petId = (Integer)respArr.get(0);
        String petName = (String)respArr.get(1);
        Integer petAge = (Integer)respArr.get(2);
        String petMaster = (String)respArr.get(3);
//        Long bornTime = Long.parseLong(respArr.get(4).toString());
        Integer petStatus = (Integer)respArr.get(5);
//        Object transTime = respArr.get(6);
        PetInfo petInfo = new PetInfo(petId, petName, petAge, petMaster,petStatus);
        return Result.ok(petInfo);
    }

    @Override
    public Result removePet(JSONArray controllerParam) {
        JSONObject removePet = weBASEUtil.getJsonParam("removePet", controllerParam, owner);
        String resp = weBASEUtil.httpPost(removePet.toString());
        JSONObject respObject = JSONObject.parseObject(resp);
        Result result = Result.ok("success");
        if(!(Boolean) respObject.get("statusOK")){
            result = Result.error(respObject.get("message"));
        }
        return result;
    }

    @Override
    public Result getAllPetToList() {
        Result allPet = getAllPet();
        Integer petAmount = (Integer)allPet.getData();
        ArrayList<Object> allPets = new ArrayList<>();
        if(petAmount > 0){
            for(int i = 1; i <= petAmount; i++){
                JSONArray objects = new JSONArray();
                objects.add(i);
                Result pet = getPet(objects);
                Object data = pet.getData();
                allPets.add(data);
            }
        }else{
            return Result.error("当前没有宠物");
        }

        return Result.ok(allPets);
    }

}
