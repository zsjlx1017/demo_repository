package com.sb.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sb.mapper.UserMapper;
import com.sb.pojo.MasterInfo;
import com.sb.pojo.User;
import com.sb.service.MasterService;
import com.sb.service.UserService;
import com.sb.utils.Result;
import com.sb.utils.WeBASEUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserServiceImpl implements UserService {


    @Autowired
    private UserMapper userMapper;

    @Autowired
    private WeBASEUtil weBASEUtil;

    @Autowired
    private MasterService masterService;

    @Value("${bcos.owner}")
    private String owner;

    @Override
    public Result login(String masterAddress, String masterPassword) {
        log.info("登录业务触发");
        User user = userMapper.selectOneByAddress(masterAddress);
        Result r = Result.ok("null");
        if(user != null && user.getMasterPassword().equals(masterPassword)){
        }else{
            r = Result.error("账号不存在或密码错误");
        }
        return r;
    }

    @Override
    public Result register(String masterAddress, String masterName, String masterPassword) {
        System.out.println("注册业务触发");
        User user1 = userMapper.selectOneByAddress(masterAddress);
        if(user1 != null){
            return Result.error("用户已存在");
        }
        User user = new User(null, masterAddress, masterName, masterPassword, "1");
        int i = userMapper.insertOne(user);

        JSONArray controllerParam = new JSONArray();
        controllerParam.add(masterAddress);
        controllerParam.add(masterName);
        controllerParam.add("1");
        JSONObject addMaster = weBASEUtil.getJsonParam("addMaster", controllerParam, owner);
        String resp = weBASEUtil.httpPost(addMaster.toString());
        JSONObject respObj = JSONObject.parseObject(resp);


        Result r;
        if(i > 0 && (Boolean) respObj.get("statusOK")){
            r = Result.ok(i);
        }else{
            r = Result.error("error");
        }
        return r;
    }

    @Override
    public Result getUser(String masterAddress) {
//        User user = userMapper.selectOneByAddress(masterAddress);
        JSONArray controllerParam = new JSONArray();
        controllerParam.add(masterAddress);
        Result master = masterService.getMaster(controllerParam);
        JSONObject jsonObject = new JSONObject();
        MasterInfo data = (MasterInfo)master.getData();
        jsonObject.put("masterName",data.getMasterName());
        jsonObject.put("money",data.getMoney());
        return master.getData() != null ?  Result.ok(jsonObject) : Result.error(null);
    }
}
