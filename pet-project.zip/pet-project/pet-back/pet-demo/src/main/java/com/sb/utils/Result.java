package com.sb.utils;

import lombok.Data;

@Data
public class Result {

    private Integer code;
    private String msg;
    private Object data;

    public static Result ok(Object data){
        Result result = new Result();
        result.code = 200;
        result.msg = "success";
        result.data = data;
        return  result;
    }

    public static Result error(Object data){
        Result result = new Result();
        result.code = 500;
        result.msg = "error";
        result.data = data;
        return  result;
    }

}
