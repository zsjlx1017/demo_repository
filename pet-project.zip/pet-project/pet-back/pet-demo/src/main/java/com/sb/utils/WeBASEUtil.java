package com.sb.utils;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.nio.charset.Charset;

@Repository
public class WeBASEUtil {

    private static String contractName = "Pet";

    @Value("${bcos.contractAddress}")
    private String contractAddress;

    @Value("${bcos.url}")
    private String url;

    public String httpPost(String jsonStr){
        CloseableHttpClient aDefault = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url);
        httpPost.setHeader("Content-Type","application/json;charset=utf-8");

        StringEntity stringEntity = new StringEntity(jsonStr, Charset.forName("UTF-8"));
        stringEntity.setContentEncoding("UTF-8");
        stringEntity.setContentType("application/json");

        httpPost.setEntity(stringEntity);
        CloseableHttpResponse resp;
        String result = null;

        try {
            resp = aDefault.execute(httpPost);
            result = EntityUtils.toString(resp.getEntity(),"UTF-8");

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    public JSONObject getJsonParam(String funcName, JSONArray params, String senderAddress){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("contractName",contractName);
        jsonObject.put("contractAddress",contractAddress);
        jsonObject.put("contractAbi",JSONArray.parseArray(Pet.ABI));
        jsonObject.put("funcName",funcName);
        jsonObject.put("funcParam",params);
        jsonObject.put("user",senderAddress);
        jsonObject.put("groupId", "1");
        jsonObject.put("contractPath", "/");
        return  jsonObject;
    }

}
