<script setup>
import {useRouter} from "vue-router"

const router = useRouter()

function change(path){
    router.push(path)
}

</script>
<template>
    <div class="box">
        <div class="list" @click="change('/petList')">
        宠物列表
        </div>
        <div class="list" @click="change('/addPet')">
        添加宠物
        </div>
        <div class="list" @click="change('/transferPet')">
        宠物交易
        </div>
        <div class="list" @click="change('/myInfo')">
        个人详情
        </div>
    </div>
</template>
<style scoped>
.list{
    height: 80px;
    background-color: #3BD4FF;
    text-align: center;
    line-height: 80px;
    color: white;
}
.list:hover{
    background-color: #00C7FF;
    cursor: pointer;
}

</style>