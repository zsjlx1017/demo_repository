<script setup>
import {onMounted,ref,reactive,onUpdated} from 'vue'
import axios from '../axios/index.js'
import {useRouter} from 'vue-router'
const router = useRouter()
let master = reactive({
    masterName:'',
    money:''
})
let masterAddress = window.localStorage.getItem("masterAddress")
onMounted(()=>{
    getMaster()
})
onUpdated(()=>{
    getMaster()
})

function getMaster(){
    axios.get(`user/getUser?masterAddress=${masterAddress}`).then(resp=>{
        if(resp.data.code == 200){
            master.masterName = resp.data.data.masterName
            master.money = resp.data.data.money
            console.log(master);
        }else{
            alert(`查询失败${resp.data.data}`)
        }
    }).catch(error=>{
        console.log(error);
    })
}
function logout(){
    window.localStorage.removeItem('masterAddress')
    router.push('/login')
}
let reg = /^[0-9]*$/
function recharge(){
    let amount = prompt('请输入充值金额')
    if(amount == '' || !reg.test(amount)){
        alert('数量不能为空且必须为正整数')
    }else{
        let postData = new Object();
        postData.masterAddress = masterAddress
        postData.amount = amount
        console.log(postData);
        axios.post('master/addMoney',postData).then(resp=>{
            if(resp.data.code == 200){
                alert('充值成功!')
                getMaster()
            }else{
                alert(`充值失败${resp.data.data}`)
            }
        }).catch(error=>{
            console.log(error);
        })
    }
}
</script>
<template>
    <div id="box">
        <span class="left">
         <h2>欢迎使用宠物商店管理系统: {{ master.masterName }} 
         <span>您的余额为:{{ master.money }}元</span>
         
        </h2>
        
        </span>
        <span>
            <button @click="logout" class="right">退出登录</button>
            <span><button @click="recharge" class="left">充值</button></span>
        </span>
    </div>
</template>
<style scoped>
.box{
    overflow: hidden;
}
.left{
    float: left;
    box-sizing: border-box;
}
.right{
    float: right;
    width: 100px;
    cursor: pointer;
    height: 30px;
    border: 0;
    border-radius: 20px
}
button{
    width: 80px;
    height: 30px;
    border-radius: 20px;
    border: 0;
    margin-left: 10px;
}
</style>