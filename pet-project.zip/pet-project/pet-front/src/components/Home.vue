<script setup>
import Header from './Header.vue'
import Asider from './Asider.vue'
import Main from './Main.vue'
</script>
<template>
    <div class="box">
        <Header id="header" />
        <Asider id="asider" />
        <div id="main">
            <router-view></router-view>
        </div>
    </div>
</template>
<style scoped>
*{
    padding: 0;
    margin: 0;
}
.box{
    width: 100%;
    height: 100%;
    background-color: #f9f9f9;
}
#header{
    height: 80px;
    width: 100%;
    box-sizing: border-box;
    padding: 25px 80px;
    background-color: #00C7FF;
    color: white;
}
#asider{
    height: 100%;
    width: 10%;
    float: left;
    box-sizing: border-box;
    background-color: #3BD4FF;

}
#main{
    height: 100%;
    width: 90%;
    float: left;
    box-sizing: border-box;
}


</style>