<template>
    <div class="addPetbox">
        宠物姓名: <input type="text" name="" id="" v-model="pet.petName">
        <br />
        宠物年龄: <input type="text" name="" id="" v-model="pet.petAge">
        <br />
        <button @click="submit">
            提交
        </button>
        <button @click="clear">
            清空
        </button>
    </div>
</template>
<script setup>
import { useRouter } from 'vue-router';
import {ref,reactive} from 'vue'
import axios from '../axios/index';
let pet = reactive({
    petName:'',
    petAge:''
})

function submit(){
    let reg = /^[0-9]*$/
    if(pet.petName == '' || pet.petAge == ''){
        alert('宠物姓名或者年龄不能为空')
    }else if(!reg.test(pet.petAge)){
        alert('年龄必须为数字')
    }else{
        let postData = new Object()
        postData.petName = pet.petName
        postData.petAge = pet.petAge
        console.log(postData);
        axios.post('pet/addPet',postData).then(resp=>{
            if(resp.data.code == 200){
                alert('新增成功!')
                pet.petName = ''
                pet.petAge = ''
            }else{
                alert(`新增失败${resp.data.data}`)
            }
        }).catch(error=>{
            console.log(error);
        })
    }
    
}
function clear(){
    pet.petName = ''
    pet.petAge = ''
}

</script>
<style scoped>
.addPetbox{
    /* border: 1px solid #000; */
    width: 500px;
    margin:auto ;
    margin-top: 100px;
}
input{
    width: 300px;
    height: 30px;
    margin-top: 50px;
}
button{
    margin-left: 60px;
    margin-top: 40px;
    width: 120px;
    height: 35px;
    border-radius: 30px;
    border: 0;
}
button:nth-of-type(1){
    background-color: #00C7FF;
    color: white;
}
</style>