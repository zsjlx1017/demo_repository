<script setup>
import {ref,reactive} from 'vue'
import {useRouter} from 'vue-router'
import axios from '../axios/index'
const router = useRouter()

let master = reactive({
    address:'',
    password:''
})

function register(){
    router.push("/register")
}
function login(){
    let postData = new Object()
    postData.masterAddress = master.address,
    postData.masterPassword = master.password
    console.log(postData);

    let begin = postData.masterAddress.substring(0,2)
    if(begin != '0x'){
        alert('地址需要以0x开头')
    }else{
        axios.post('user/login',postData).then(resp=>{
         if(resp.data.code == 200){
            alert('登陆成功！即将跳转')
            window.localStorage.setItem('masterAddress', master.address)
            router.push('/')
        }else{
            alert(`登陆失败！${resp.data.data}`)
        }
        }).catch(error=>{
            console.log(error);
        })
    }
    

}
</script>
<template>

<div class="box">
    <ul>
        <li>欢迎使用宠物商店管理系统</li>
        <li>
            地址:
            <input type="text" v-model="master.address"/>
        </li>
        <li>
            密码:
            <input type="password" v-model="master.password"/>
        </li>
        
        <li>
            <button @click="login">登录</button>
            <button @click="register">注册</button>
        </li>
    </ul>
</div>

</template>
<style scoped>
*{
    padding: 0;
    margin: 0;
}
.box{
    width: 500px;
    height: 400px;
    background-color: white;
    margin: auto;
    border-radius: 20px;
    margin-top: 15%;
    box-sizing: border-box;
    padding: 60px;
    opacity: 0.7;
}
ul li{
    list-style: none;
    margin-top: 50px;
    font-size: 130%;
}
ul li:nth-of-type(1){
    text-align: center;
    font-size: 31px;
    margin-top: 0px;
    
}
ul li:nth-of-type(2){
    margin-left: 20px;
}
ul li:nth-of-type(3){
    margin-left: 20px;
}
ul li:nth-of-type(4){
    margin-top: 60px;
}
ul li:nth-of-type(4) button{
    margin-left: 80px;
    width: 85px;
    height: 40px;
    border-radius: 20px;
    border: 0px;
    background-color: #89CFF0;
}

input{
    width: 280px;
    height: 25px;
}
</style>