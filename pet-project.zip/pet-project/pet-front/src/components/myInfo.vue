<script setup>
    import axios from '../axios/index';
    import {ref,reactive,onMounted,onUpdated} from 'vue'
    let masterAddress = window.localStorage.getItem('masterAddress')
    let master = ref('')
    let myPet = ref('')
    onMounted(()=>{
        getMyInfo()
        getMyPet()
    })
    function getMyInfo(){
        axios.get(`master/getMaster?masterAddress=${masterAddress}`).then(resp=>{
            if(resp.data.code == 200){
                master.value = resp.data.data
                console.log(master.value);
            }else{
                alert(`查询失败${resp.data.data}`)
            }
        }).catch(error=>{
            console.log(error);
        })
    }

    function getMyPet(){
        axios.get(`master/getMyPetToList?masterAddress=${masterAddress}`).then(resp=>{
            if(resp.data.code == 200){
                myPet.value = resp.data.data
                console.log(myPet.value);
            }else{
                alert(`查询失败${resp.data.data}`)
            }
        }).catch(error=>{
            console.log(error);
        })
    }
</script>
<template>
    <div class="myInfo">
        我的信息
        <hr style="border: 2px solid gray; margin:10px 0;"/>
        名称: {{ master.masterName }} 
        地址: {{ masterAddress }}
        余额: {{ master.money  }} 元
    </div>
    <div class="myPet">
        <div class="head">
        我的宠物
        <hr style="border: 2px solid gainsboro; margin:10px 0;"/>
        </div>
        <div class="bottom">
                <ul>
                    <li>宠物编号
                    </li>
                    <li>宠物名称
                    </li>
                    <li>宠物年龄
                    </li>
                    <li>宠物状态
                    </li>
                </ul>
        </div>

        <div class="myPetList">
            <table >
                <tr v-for="(item,index) in myPet">
                    <td>
                        {{ item.petId }}
                    </td>
                    <td>
                        {{ item.petName }}
                    </td>
                    <td>
                        {{ item.petAge }}
                    </td>
                    <td>
                        {{ item.petStatus == 1 ? '正常' : '异常' }}
                    </td>
                </tr>
            </table>
        </div>
    </div>
</template>

<style scoped>
    .myInfo{
        width: 95%;
        /* border: 1px solid #000; */
        margin: 50px auto;
    }
    .myPet{
        width: 95%;
        /* border: 1px solid #000; */
        margin: 50px auto;
    }

    .bottom{
        overflow: hidden;
    }

    table tr td{
        padding-left: 20vw;
    }
    table tr td:nth-of-type(1){
        padding-left: 1vw;
    }
    table tr td:nth-of-type(2){
        padding-left: 24.1vw;
    }
    table tr td:nth-of-type(3){
        padding-left: 23.5vw;
    }
    table tr td:nth-of-type(4){
        padding-left: 24vw;
    }
    
    
    

    .myPetList{
        overflow: hidden;
    }

    ul li{
        list-style: none;
        float: left;
        margin-left: 21.8vw;
    }
    ul li:nth-of-type(1){
        margin-left: 0;
    }
    
</style>