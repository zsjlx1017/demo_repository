<script setup>
import axios from '../axios/index'
import {ref,reactive,onMounted,onUpdated,onBeforeUpdate} from 'vue'
let petList = ref([]);
let masterAddress = window.localStorage.getItem("masterAddress")

function query(){
   axios.get('/pet/getAllPetToList').then(resp=>{
        if(resp.data.code == 200){
            petList.value = resp.data.data
            console.log(petList);
        }
    })
}
onMounted(()=>{
    query()
})

function submit(index){
    let postData = new Object();
    postData.applicant = masterAddress
    postData.petId = index
    console.log(postData);
    axios.post('/master/savePet',postData).then(resp=>{
        if(resp.data.code == 200){
            alert('领养成功')
            query()
        }else{
            alert(`领养失败${resp.data.data}`)
            query()
        }
    }).catch(error=>{
        console.log(error);
    })
}


</script>
<template>
    
<div class="list">
    <ul>
        <li>
            宠物编号
        </li>
        <li>
            宠物姓名
        </li>
        <li>
            宠物年龄
        </li>
        <li>
            宠物主人
        </li>
        <li>
            宠物状态
        </li>
    </ul>
</div>
<div class="table">
    <table v-if="petList.length > 0">
        <tr v-for="(item,index) in petList">
            <td>
                {{ item.petId }}
            </td>
            <td>
                {{ item.petName }}
            </td>
            <td>
                {{ item.petAge }}
            </td>
            <td>
                {{ item.petMaster }}
            </td>
            <td>
                {{ item.petStatus == 1 ? '正常' : '异常' }}
            </td>

            <td>
                <button @click="submit(item.petId)">领养</button>
            </td>
        </tr>
    </table>
</div>
<!-- <div class="list-bottom" >
    <div class="info-list" v-for="(item,index) in petList">
        <div class="info">
            {{ item.petId }}
        </div>
        <div class="info">
            {{ item.petName }}
        </div>
        <div class="info">
            {{ item.petAge }}
        </div>
        <div class="info">
            {{ item.petMaster }}
        </div>
        <div class="info">
            {{ item.petStatus == 1 ? '正常' : '异常' }}
        </div>
    </div>    
</div> -->
</template>

<style scoped>
.list{
    width: 100%;
    /* border: 1px solid #000; */
    overflow: hidden;
    box-sizing: border-box;
    background-color: gainsboro;
    height: 40px;
    line-height: 40px;
}
ul:nth-of-type(1) li{
    list-style: none;
    float: left;
    margin-left: 15vw;
}
ul:nth-of-type(1) li:nth-of-type(1){
    margin-left: 5vw;
}
ul:nth-of-type(1) li:nth-of-type(2){
    margin-left: 7vw;
}
ul:nth-of-type(1) li:nth-of-type(3){
    margin-left: 7vw;
}
ul:nth-of-type(1) li:nth-of-type(4){
    margin-left: 13vw;
}


.table{
    width: 100%;
}
table tr td{
    padding-left: 6vw;
    padding-top: 5px;
}
table tr td:nth-of-type(1){
    padding-left: 6vw;
}
table tr td:nth-of-type(2){
    padding-left: 9vw;
}
table tr td:nth-of-type(3){
    padding-left: 9vw;
}
table tr td:nth-of-type(4){
    padding-left: 7vw;
}

button{
    width: 150px;
    height: 25px;
    border: 0;
    line-height: 25px;
    background-color: #00C7FF;
    color: white;
    border-radius: 10px;
}




</style>