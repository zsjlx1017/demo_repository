<template>

    <div class="mypet">
        您的地址为:&nbsp;<span style="text-decoration: underline;">{{ masterAddress }}</span>
        &nbsp;您当前可供交易的宠物编号为:
        <span v-for="(item,index) in myPet">
            <span v-if="item != '0'" style="margin-left: 5px;"> {{ item }} </span>
        </span>
    </div>

    <div class="transferPetBox">
        宠物来自地址: <input type="text" name="" id="" v-model="transfer.from">
        <br />
        发送宠物编号: <input type="text" name="" id="" v-model="transfer.petId">
        <br />
        宠物去往地址: <input type="text" name="" id="" v-model="transfer.to">
        <br />
        <button @click="submit">
            提交
        </button>
        <button @click="clear">
            清空
        </button>
    </div>
</template>
<script setup>
import {ref,reactive,onMounted} from "vue"
import axios from "../axios/index"
import { useRouter } from "vue-router";
let masterAddress = window.localStorage.getItem('masterAddress')
let myPet = ref([])
let transfer = reactive({
    from:'',
    petId:'',
    to:''
})
let reg = /^[0-9]*$/
onMounted(()=>{
    getMyPet()
})

function getMyPet(){
    axios.get(`master/getMyPet?masterAddress=${masterAddress}`).then(resp=>{
    if(resp.data.code == 200){
        myPet.value = resp.data.data
        console.log(myPet.value);
    }
    }).catch(error=>{
        console.log(error);
    })
}

let toMaster;

async function submit(){
    
    if(transfer.from == '' || transfer.petId == '' || transfer.to == ''){
        alert('输入内容不能为空')
    }else if(!transfer.from.startsWith('0x') || !transfer.to.startsWith('0x')){
        alert('输入地址必须是0x开头')
    }else if(!reg.test(transfer.petId)){
        alert('宠物编号必须为数字')
    }else{
        let flag = false
        for(let i = 0; i < myPet.value.length; i++){
            if(myPet.value[i] == transfer.petId){
                flag = true
                break
            }else{
                flag = false
            }
        }
        if(flag){
            await checkUser()
            let isSend = confirm(`确认要发送给地址为：${transfer.to} 名字为：${toMaster} 的用户吗`)
            console.log(isSend);
            if(isSend){
                let postData = new Object();
                postData.from = transfer.from
                postData.to = transfer.to
                postData.petId = transfer.petId
                console.log(postData);
                axios.post('master/transferPet',postData).then(resp=>{
                    if(resp.data.code == 200){
                        alert('转移成功!')
                        getMyPet()
                    }else{
                        alert(`转移失败${resp.data.data}`)
                    }
                }).catch(error=>{
                    console.log(error);
                })
            }else{
                alert('您点了取消')
            }
        }else{
            alert('您没有当前宠物')
        }
        
    }
}

async function checkUser(){
    await axios.get(`master/getMaster?masterAddress=${transfer.to}`).then(resp=>{
        if(resp.data.code == 200){
            toMaster = resp.data.data.masterName
            console.log(toMaster);
        }else{
            alert(`查询失败${resp.data.data}`)
        }
    }).catch(error=>{
        console.log(error);
    })
}






</script>
<style scoped>
.mypet{
    margin: 20px 50px;
}

.transferPetBox{
    /* border: 1px solid #000; */
    width: 600px;
    margin:auto ;
    margin-top: 50px;
}
input{
    width: 400px;
    height: 30px;
    margin-top: 50px;
}
button{
    margin-left: 120px;
    margin-top: 40px;
    width: 120px;
    height: 35px;
    border-radius: 30px;
    border: 0;
}
button:nth-of-type(1){
    background-color: #00C7FF;
    color: white;
}
</style>