import {createRouter,createWebHashHistory} from 'vue-router'
const router = createRouter({
    history: createWebHashHistory(),
    routes:[
        {
            path: '/',
            redirect:'/petList',
            component: () => import("../components/Home.vue"),
            children:[
                {
                    path:'/petList',
                    component:()=>import("../components/petList.vue")
                },
                {
                    path:'/addPet',
                    component:()=>import("../components/addPet.vue")
                },
                {
                    path:'/transferPet',
                    component:()=>import("../components/transferPet.vue")
                },
                {
                    path:'/myInfo',
                    component:()=>import("../components/myInfo.vue")
                }
            ]
        },
        {
            path: '/login',
            component: () => import("../components/login.vue")
        },
        {
            path: '/register',
            component: () => import("../components/register.vue")
        },
        {
            path:'/main',
            redirect:'/petList',
            component:()=>import("../components/Main.vue")
        }
    ]
})

router.beforeEach((to,from,next)=>{
    if(to.path == '/register' || to.path == '/login'){
        next()
    }else{
       let master = window.localStorage.getItem("masterAddress")
       console.log(master);
       if(master == '' || master == null){
            next('/login')
            // next()
       }else{
        next()
       }
    }
})

export default router
