package com.sb.config;

import org.fisco.bcos.sdk.BcosSDK;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.config.Config;
import org.fisco.bcos.sdk.config.ConfigOption;
import org.fisco.bcos.sdk.config.model.ConfigProperty;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.model.CryptoType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@Configuration
public class bcosConfig {

    @Value("${bcos.certPath}")
    private String certPath;

    @Value("${bcos.nodeList}")
    private String nodeList;

    @Value("${bcos.accountPemPath}")
    private String accountPemPath;

    @Value("${bcos.groupId}")
    private String groupId;


    public ConfigProperty setConfig(){
        ConfigProperty config = new ConfigProperty();
        HashMap<String, Object> certHash = new HashMap<String,Object>();
        certHash.put("certPath", certPath);
        config.setCryptoMaterial(certHash);

        HashMap<String, Object> peers = new HashMap<String, Object>();
        String[] split = nodeList.split(",");
        List<String> list = Arrays.asList(split);
        peers.put("peers", list);
        config.setNetwork(peers);

        HashMap<String, Object> accounts = new HashMap<String, Object>();
        accounts.put("keyStoreDir", "account");
        accounts.put("accountAddress","");
        accounts.put("accountFileFormat","pem");
        accounts.put("password","");
        accounts.put("accountFilePath", accountPemPath);
        config.setAccount(accounts);

        return config;
    }

    @Bean(name = "configOption")
    public ConfigOption getConfig() throws Exception{
        return new ConfigOption(setConfig(), CryptoType.ECDSA_TYPE);
    }
    @Bean(name = "bcosSDK")
    public BcosSDK getSdk(ConfigOption configOption){
        return new BcosSDK(configOption);
    }
    @Bean(name = "client")
    public Client getClient(BcosSDK bcosSDK){
        return bcosSDK.getClient(Integer.parseInt(groupId));
    }
    @Bean
    public CryptoKeyPair getCryptoKeyPair(Client client){
        return client.getCryptoSuite().getCryptoKeyPair();
    }



}
