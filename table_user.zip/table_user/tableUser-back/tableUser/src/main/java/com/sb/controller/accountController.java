package com.sb.controller;

import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.crypto.CryptoSuite;
import org.fisco.bcos.sdk.crypto.hash.Keccak256;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.crypto.signature.SignatureResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.*;

import java.security.KeyPair;

@Slf4j
@RestController
@CrossOrigin
public class accountController {

    @Autowired
    private Client client;

    @GetMapping("createKey")
    public JSONObject createKey(){
        //随机生成一个公钥私钥对
        CryptoSuite cryptoSuite = new CryptoSuite(1);
        CryptoKeyPair keyPair = cryptoSuite.createKeyPair();
        //获取公钥私钥对信息
        String hexPrivateKey = keyPair.getHexPrivateKey();
        String hexPublicKey = keyPair.getHexPublicKey();
        String address = keyPair.getAddress();
        log.info("createKey -------------------------------------Success ");
        log.info("privateKey --------> "+hexPrivateKey);
        log.info("publicKey --------> "+hexPublicKey);
        log.info("address --------> "+address);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("privateKey:", hexPrivateKey);
        jsonObject.put("publicKey:", hexPublicKey);
        jsonObject.put("address:", address);
        return jsonObject;
    }
    @PostMapping("isKey")
    public String loadKey(@RequestBody JSONObject params){
        String privateKey = params.get("privateKey").toString();
        log.info("privateKey is: "+privateKey);
        CryptoSuite cryptoSuite = new CryptoSuite(1);
        CryptoKeyPair keyPair = cryptoSuite.getKeyPairFactory().createKeyPair(privateKey);
        if(keyPair != null){
            return "success";
        }
        return "failed";
    }

    @PostMapping("sign")
    public String sign(@RequestBody JSONObject params){
        //获取用户传入的私钥和签名数据
        String privateKey = params.get("privateKey").toString();
        String signData = params.get("signData").toString();
        log.info("privateKey------->"+privateKey);
        log.info("signData------->"+signData);
        //根据用户传入的私钥加载对应的私钥对
        CryptoSuite cryptoSuite = new CryptoSuite(1);
        CryptoKeyPair keyPair = cryptoSuite.getKeyPairFactory().createKeyPair(privateKey);
        log.info("CryptoKeyPair------->"+keyPair);
        //将用户传入的数据计算成hash值
        Keccak256 keccak256 = new Keccak256();
        String hash = keccak256.hash(signData);
        log.info("hash------->"+hash);
        //签名
        SignatureResult sign = cryptoSuite.sign(hash, keyPair);
       log.info("sign------->"+sign.convertToString());
        return sign.convertToString();
    }

}
