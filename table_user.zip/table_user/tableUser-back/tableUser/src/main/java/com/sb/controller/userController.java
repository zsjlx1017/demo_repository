package com.sb.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.annotation.JsonAppend;
import com.sb.User;
import com.sb.util.ResultUtil;
import lombok.extern.slf4j.Slf4j;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.model.TransactionReceipt;
import org.fisco.bcos.sdk.transaction.model.exception.ContractException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@Slf4j
@CrossOrigin
public class userController {

    @Autowired
    private Client client;

    @Value("${bcos.contractAddress}")
    private String contractAddress;

    /**
     * 通过userid来查询对应的user
     * @param userId
     * @return
     */
    @GetMapping("getUser")
    public ResultUtil getUser(String userId){
        User userContract = User.load(contractAddress, client, client.getCryptoSuite().getCryptoKeyPair());
        ResultUtil r = ResultUtil.error("error");
        try {
            String user = userContract.getUser(userId);
            JSONObject jsonObject = convertStringToJson(user);
            r = ResultUtil.ok(jsonObject);
        } catch (Exception e) {
            log.warn("[USERCONTROLLER][getUser]-----> user is not exist");
        }
        return r;
    }

    /**
     * 通过前端传入的params 获取userid 获取username 获取userage来进行上链
     * @param params
     * @return
     */
    @PostMapping("addUser")
    public ResultUtil addUser(@RequestBody JSONObject params){
        ResultUtil r = null;
        String userId = params.get("userId").toString();
        String userName = params.get("userName").toString();
        String userAge = params.get("userAge").toString();
        //进行添加之前险查询该id的用户是否存在 存在即返回不让再次添加
        ResultUtil user = getUser(userId);
        if (user.getCode() == 200) {
            r = ResultUtil.error("user is already exist");
            return r;
        }
        log.info("[USERCONTROLLER][addUser]-----> userId: "+userId+" userName: "+userName+" userAge: "+userAge);
        //否则加载合约进行上链
        User userContract = User.load(contractAddress, client, client.getCryptoSuite().getCryptoKeyPair());
        TransactionReceipt transactionReceipt = userContract.addUser(userId, userName, userAge);
        if (transactionReceipt.isStatusOK()) {
            r = ResultUtil.ok("ok");
        }
        return r;
    }

    /**
     * 获取链上所有的user信息
     * @return
     */

    @GetMapping("getAllUser")
    public ResultUtil getAllUser(){
        User userContract = User.load(contractAddress, client, client.getCryptoSuite().getCryptoKeyPair());
        ResultUtil r = ResultUtil.error("list is null");
        try {
            List allUser = userContract.getAllUser();
            JSONArray objects = new JSONArray();
            for (Object o : allUser) {
                JSONObject jsonObject = convertStringToJson(o.toString());
                objects.add(jsonObject);
                r = ResultUtil.ok(objects);
            }
        } catch (Exception e) {
            log.error("[USERCONTROLLER][getAllUser]-----> list is null");
        }
        return r;
    }


    /**
     * 根据用户传入的userid来获取对应的user 并将其删除
     * @param userId
     * @return
     */
    @GetMapping("removeUser")
    public ResultUtil removeUser(String userId){
        User userContract = User.load(contractAddress, client, client.getCryptoSuite().getCryptoKeyPair());
        ResultUtil r = ResultUtil.ok("ok");
        //首先查询该user是否存在
        ResultUtil user = getUser(userId);
        if (user.getCode()!=200) {
            r = ResultUtil.error("user is not exist");
        }else{
            TransactionReceipt transactionReceipt = userContract.removeUser(userId);
            String output = transactionReceipt.getOutput();
            int i = Integer.parseInt(output.substring(output.length() - 1));
            if(i < 0){
                r = ResultUtil.error("remove failed");
            }
        log.info("[USERCONTROLLER][removeUser]-----> removeUser"+(i > 0 ? "success" : "failed"));
        }
        return r;
    }






    private JSONObject convertStringToJson(String str) {
        JSONObject jsonObject = new JSONObject();
        String[] split1 = str.split(",");
        for (String s : split1) {
            String[] split2 = s.split(":");
            for (int i = 0; i < split2.length; i++) {
                if(i == 0 || i % 2 == 0){
                    jsonObject.put(split2[i], i == 0 ? split2[i+1] : split2[i-1]);
                }
            }
        }

        return jsonObject;
    }
}
