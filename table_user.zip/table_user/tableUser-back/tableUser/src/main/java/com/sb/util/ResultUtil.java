package com.sb.util;

import lombok.Data;

@Data
public class ResultUtil {

    private Integer code;
    private Object data;
    public static ResultUtil ok(Object data){
        ResultUtil resultUtil = new ResultUtil();
        resultUtil.code = 200;
        resultUtil.data = data;
        return resultUtil;
    }

    public static ResultUtil error(Object data){
        ResultUtil resultUtil = new ResultUtil();
        resultUtil.code = 500;
        resultUtil.data = data;
        return resultUtil;
    }

}
