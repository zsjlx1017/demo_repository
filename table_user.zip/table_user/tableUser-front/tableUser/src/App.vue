<script setup>
import Home from "./components/Home.vue"
</script>

<template>
<Home></Home>
</template>

<style scoped>

</style>
