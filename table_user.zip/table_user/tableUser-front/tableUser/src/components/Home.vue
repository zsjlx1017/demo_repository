<template>
    <div class="common-layout">
        <el-container>
            <el-aside class="aside">
                <el-radio-group v-model="isCollapse" style="margin-bottom: 20px">
                    <el-radio-button :value="false">expand</el-radio-button>
                    <el-radio-button :value="true">collapse</el-radio-button>
                </el-radio-group>
                <el-menu default-active="2" class="el-menu-vertical-demo" :collapse="isCollapse" @open="handleOpen"
                    @close="handleClose">
                    <el-sub-menu index="1">
                        <template #title>
                            <el-icon>
                                <location />
                            </el-icon>
                            <span>Navigator One</span>
                        </template>
                        <el-menu-item-group>
                            <template #title><span>Group One</span></template>
                            <el-menu-item index="1-1">item one</el-menu-item>
                            <el-menu-item index="1-2">item two</el-menu-item>
                        </el-menu-item-group>
                        <el-menu-item-group title="Group Two">
                            <el-menu-item index="1-3">item three</el-menu-item>
                        </el-menu-item-group>
                        <el-sub-menu index="1-4">
                            <template #title><span>item four</span></template>
                            <el-menu-item index="1-4-1">item one</el-menu-item>
                        </el-sub-menu>
                    </el-sub-menu>
                    <el-menu-item index="2">
                        <el-icon><icon-menu /></el-icon>
                        <template #title>Navigator Two</template>
                    </el-menu-item>
                    <el-menu-item index="3" disabled>
                        <el-icon>
                            <document />
                        </el-icon>
                        <template #title>Navigator Three</template>
                    </el-menu-item>
                    <el-menu-item index="4">
                        <el-icon>
                            <setting />
                        </el-icon>
                        <template #title>Navigator Four</template>
                    </el-menu-item>
                </el-menu>
            </el-aside>


            <!-- 主题 -->
            <el-main class="main">
                <el-table :data="filterTableData" height="400px" style="width: 100%">
                    <el-table-column label="Id" prop="userId" fixed />
                    <el-table-column label="Name" prop="userName" />
                    <el-table-column label="Age" prop="userAge" />
                    <el-table-column>
                        <template #header>
                            <el-input v-model="search" size="small" placeholder="Type to search" />
                        </template>
                        <template #default="scope">
                            <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">
                                删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <el-button type="primary" @click="dialogFormVisible = true" style="width: 100%; height: 40px;"
                    plain>新增</el-button>
                <div class="box">
                    <div class="blocks">
                        区块数量: {{ blockData.blockNumber }}
                    </div>
                    <div class="peers">
                        节点数量: {{ blockData.peers }}
                    </div>
                    <div class="deals">
                        交易数量: {{ blockData.deals }}
                    </div>
                </div>
                <div class="search">
                    <!-- 111111 -->
                    <el-button :icon="Search" circle @click="searchBlock"/>&nbsp;
                    <el-input v-model="blockHeight" placeholder="输入区块编号查看区块信息" style="width: 95%;"></el-input>
                </div>
            </el-main>
        </el-container>
    </div>

    <el-dialog v-model="dialogFormVisible" style="padding: 30px;" title="添加用户" width="40%">
        <el-dialog v-model="innerVisible" width="500" title="确认提交这些信息吗" append-to-body>
            <el-form>
                <el-form-item label="用户id">
                    {{ form.userId }}
                </el-form-item>
                <el-form-item label="用户名称">
                    {{ form.userName }}
                </el-form-item>
                <el-form-item label="用户年龄">
                    {{ form.userAge }}
                </el-form-item>
            </el-form>
            <el-button @click="innerVisible = false">取消</el-button>
            <el-button @click="addUser" type="primary" :disabled="addFlag">确认</el-button>
        </el-dialog>
        <el-form :model="form" ref="ruleFormRef" :rules="rules">
            <el-form-item label="用户Id" prop="userId" :label-width="formLabelWidth">
                <el-input v-model="form.userId" autocomplete="off" maxlength="18" show-word-limit clearable />
            </el-form-item>
            <el-form-item label="用户名称" prop="userName" :label-width="formLabelWidth">
                <el-input v-model="form.userName" autocomplete="off" maxlength="10" show-word-limit clearable />
            </el-form-item>
            <el-form-item label="用户年龄" prop="userAge" :label-width="formLabelWidth">
                <el-date-picker type="date" placeholder="请选择日期" v-model="form.userAge" clearable
                    value-format="YYYY/MM/DD" />
            </el-form-item>
        </el-form>
        <template #footer>
            <div class="dialog-footer">
                <el-button @click="resetForm(ruleFormRef)">取消</el-button>
                <el-button type="primary" @click="submitForm(ruleFormRef)">
                    添加
                </el-button>
            </div>
        </template>
    </el-dialog>
<!-- 区块信息 -->
    <el-dialog
    v-model="dialogVisible2"
    :title="Tips"
    width="80%"
    :before-close="handleClose2"
  >
    <span v-for="(value,key) in blockMsg.data"> <b>{{ key }}</b> : {{ value }} <br/></span>
  </el-dialog>
</template>
<script lang="ts" setup>
import {
  Search,
} from '@element-plus/icons-vue'
import { computed, ref, onMounted, onUpdated, reactive } from 'vue'
import axios from 'axios'
import {
    Document,
    Menu as IconMenu,
    Location,
    Setting,
} from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance, FormRules  } from 'element-plus'
interface User {
    userName: string
    userId: string
    userAge: string
}
let dialogFormVisible = ref(false)
let innerVisible = ref(false)
const formLabelWidth = '140px'
let form = reactive<User>({
    userId: '',
    userName: '',
    userAge: ''
})
const checkAge = (rule: any, value: any, callback: any) => {

    if (value == '') {
        callback(new Error('请选择出生日期'))
    } else {
        let inputDate = new Date(value).getTime()
        let nowDate = new Date().getTime()
        if (inputDate > nowDate) {
            callback(new Error('选择的出生日期必须小于当前日期'))
        }
    }
    callback()
}

const ruleFormRef = ref<FormInstance>()
const rules = reactive<FormRules<User>>({
    userId: [{ required: true, message: '请输入用户id(只能输入数字)', trigger: 'blur', pattern: /^\d*$/ }],
    userName: [{ required: true, message: '请输入用户名称(只能输入中文、英文、日文、罗马数字、下划线、点符，且不能以下划线开头或结尾)', trigger: 'blur', pattern: /^(?!_)(?!.*?_$)(^[a-zA-Z0-9_\u4e00-\u9fa5\.\u0800-\u4e00]+$)/ }],
    userAge: [{ required: true, validator: checkAge, trigger: 'blur' }],
})




const submitForm = (formEl: FormInstance | undefined) => {
    if (!formEl) return
    formEl.validate((valid) => {
        if (valid) {
            innerVisible.value = true
        } else {
            ElMessage.error('请检查输入的内容是否符合规范')
        }
    })
}
const resetForm = (formEl: FormInstance | undefined) => {
    if (!formEl) return
    formEl.resetFields()
    form.userId = '',
        form.userName = '',
        form.userAge = '',
        dialogFormVisible.value = false
}

const isCollapse = ref(true)
const handleOpen = (key: string, keyPath: string[]) => {
    console.log(key, keyPath)
}
const handleClose = (key: string, keyPath: string[]) => {
    console.log(key, keyPath)
}
const search = ref('')
const filterTableData = computed(() =>
    tableData.respData.filter(
        (data) =>
            !search.value ||
            data.userName.toLowerCase().includes(search.value.toLowerCase())
    )
)

const handleDelete = async (index: number, row: User) => {
    ElMessageBox.confirm(
    '确认要删除吗',
    '警告',
    {
      confirmButtonText: 'OK',
      cancelButtonText: 'Cancel',
      type: 'warning',
    }
  )
    .then(async () => {
      const response = await axios.get(`http://localhost:8080/removeUser?userId=${row.userId}`)
      if(response.data.code == 200){
        ElMessage({
            type: 'success',
            message: '删除成功',
        })
        getAllUser()
        getBlockInfo()
      }else{
        ElMessage({
            type: 'error',
            message: `删除失败: ${response.data.data}`,
        })
      }
        
        
    })
    .catch(async() => {
      ElMessage({
        type: 'info',
        message: '您点了取消',
      })
    })
}

let tableData = reactive(
    {
        respData:
            [
                {
                    userName: 'test1',
                    userId: 'test',
                    userAge: '11',
                },
            ]
    }
)

async function getAllUser() {
    let response = await axios.get("http://localhost:8080/getAllUser")
    console.log(response.data.data);
    tableData.respData = response.data.data
    console.log(tableData.respData);

}


let addFlag = ref(false)
async function addUser() {
    addFlag.value = true
    try {
        const response = await axios.post("http://localhost:8080/addUser", form)
        if (response.data.code == 200) {
            ElMessage.success(`添加成功`)
        } else {
            ElMessage.error(`添加失败` + response.data.data)
            addFlag.value = false
        }
    } catch (error) {
        ElMessage.error(`error:` + error)
    }
    innerVisible.value = false
    dialogFormVisible.value = false
    form.userId = ''
    form.userName = ''
    form.userAge = ''


    getAllUser()
    getBlockInfo()
    setTimeout(() => {
        addFlag.value = false
    }, 300)
}


let blockData = reactive({
    blockNumber:0,
    peers:0,
    deals:0
})
let blockPost = {
    jsonrpc:'2.0',
    method:"",
    params:[1],
    id:1
}

async function getBlockInfo(){
    blockPost.method = 'getTotalTransactionCount'
    const response1 = await axios.post("/block",blockPost)
    blockData.blockNumber = parseInt(response1.data.result.blockNumber, 16)
    blockData.deals = parseInt(response1.data.result.txSum, 16)

    blockPost.method = 'getGroupPeers'
    const response2 = await axios.post("/block",blockPost)
    blockData.peers = parseInt(response2.data.result.length)
    console.log(blockData);
}
//22222222
let Tips = ref('')
let blockMsg =reactive({
    data:{}
})
let dialogVisible2 = ref(false)
let blockHeight = ref()
async function searchBlock(){
    try{
        if(blockHeight.value <= 0 || blockHeight.value > blockData.blockNumber){
        ElMessage.error("请输入正确的区块编号")
    }else{
        const resp = await axios.post('/block',{
            jsonrpc:'2.0',
            method:"getBlockByNumber",
            params:[1,blockHeight.value.toString(16),true],
            id:1
        })
        Tips.value = `${blockHeight.value} 号区块的信息如下`
        console.log(resp.data.result);
        blockMsg.data = resp.data.result
        dialogVisible2.value = true
    }
    }catch(error){
        ElMessage.error(`查询出错`)
    }
}
const handleClose2 = (done: () => void) => {
    blockHeight.value = ''
      done()
}



onMounted(() => {
    getAllUser()
    getBlockInfo()
})
</script>
<style scoped>
.aside {
    width: 15%;
    box-sizing: border-box;
}

.main {
    box-sizing: border-box;
    width: 80%;
}

.el-menu-vertical-demo:not(.el-menu--collapse) {
    width: 200px;
    min-height: 400px;
}


.box{
    width: 100%;
    margin: 20px auto;
    box-sizing: border-box;
    overflow: hidden;
    display: flex;
    justify-content: space-between;
}
.box div{
    width: 400px;
    height: 200px;
    text-align: center; 
    line-height: 200px;
    color: white;
    /* font-weight: bold; */
    font-size: 120%;
}
.blocks{
    background: linear-gradient(to top right, #47befa, #37eef2);
}
.peers{
    background: linear-gradient(to top right, #466dff, #30a7ff);
}
.deals{
    background: linear-gradient(to top right, #736aff, #b287ff);
}
</style>