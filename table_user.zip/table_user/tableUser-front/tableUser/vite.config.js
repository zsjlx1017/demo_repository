import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [vue()],
  server:{
    proxy:{
      '/block':{
        target:'http://192.168.216.131:8545',
        changeOrigin:true,
        rewrite:(path)=>path.replace(/^\/block/,'')
      }
    }
  }
})
